package com.example.but05;

import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Toast;

public class AllerInfoSae implements AdapterView.OnItemClickListener {
    private PageRessource controleur;

    public AllerInfoSae(PageRessource c) {
        controleur = c;
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        Intent action;
        String v;

        Toast.makeText(view.getContext(), "Item à la position " +
                Integer.toString(i), Toast.LENGTH_SHORT);
        action = new Intent(controleur, DescSae.class);
        action.putExtra("idSae",String.valueOf(controleur.tableSae.get(i).getId()));
        controleur.startActivity(action);


    }
}