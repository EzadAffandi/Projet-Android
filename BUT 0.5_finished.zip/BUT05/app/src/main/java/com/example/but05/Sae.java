package com.example.but05;

public class Sae {
    private int id;
    private String nom;
    private String cours;
    private String td;
    private String tp;
    private String projet;
    private String description;

    public Sae(int unId, String unNom, String hrCours, String hrTd, String hrTp, String hrProjet, String uneDesc) {
        id  = unId;
        nom = unNom;
        cours = hrCours;
        td = hrTd;
        tp = hrTp;
        projet = hrProjet;
        description = uneDesc;
    }

    public int getId() {
        return this.id;
    }
    public String getNom() {
        return this.nom;
    }
    public String getCours() {
        return this.cours;
    }
    public String getTd() {
        return this.td;
    }
    public String getTp() {
        return this.tp;
    }
    public String getProjet() {
        return this.projet;
    }
    public String getDescription() {
        return this.description;
    }
}
