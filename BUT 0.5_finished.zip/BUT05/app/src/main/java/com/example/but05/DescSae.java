package com.example.but05;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class DescSae extends AppCompatActivity {
    private Intent intent;
    private TextView nomSae;
    private TextView hrCours;
    private TextView hrTd;
    private TextView hrTp;
    private TextView hrProjet;
    private TextView descSae;
    //connection
    private String urlReq;
    private URL url;
    private ExecutorService executorService;
    private Future<String> toDo;
    private String aString;
    private JSONArray jsonArray;
    private JSONObject jsonObject;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_desc_sae);
        nomSae = findViewById(R.id.nameSae);
        hrCours = findViewById(R.id.hrCours);
        hrTd = findViewById(R.id.hrTd);
        hrTp = findViewById(R.id.hrTp);
        hrProjet = findViewById(R.id.hrProjet);
        descSae = findViewById(R.id.descSae);
        descSae.setMovementMethod(new ScrollingMovementMethod());
        intent = getIntent();

        urlReq = "http://infort.gautero.fr/index2022.php?action=get&obj=sae&idSae=" + intent.getStringExtra("idSae");
        aString = urlReq;

        try {
            url = new URL(aString);
        } catch (MalformedURLException e) {
            e.printStackTrace();
            url = null;
        }
        executorService = Executors.newSingleThreadExecutor();
        toDo = lireURL(url);
        try {
            aString = toDo.get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        try {
            jsonArray = new JSONArray(aString);
            jsonObject = jsonArray.getJSONObject(0);
            nomSae.setText(Functions.getNom(jsonObject));
            hrCours.setText(Functions.getCours(jsonObject) + "h de Cours");
            hrTd.setText(Functions.getTd(jsonObject) + "h de TD");
            hrTp.setText(Functions.getTp(jsonObject) + "h de TP");
            hrProjet.setText(Functions.getProjet(jsonObject) + "h de Projet");
            descSae.setText(Functions.getDescription(jsonObject));

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    public void returnHome(View view) {
        Intent myIntent = new Intent(DescSae.this,MainActivity.class);
        DescSae.this.startActivity(myIntent);
    }

    public Future<String> lireURL(URL u) {
        return executorService.submit(() -> {
            URLConnection c;
            String inputline;
            StringBuilder codeHTML = new StringBuilder("");

            try {
                c = u.openConnection();
                //temps maximun alloué pour se connecter
                c.setConnectTimeout(60000);
                //temps maximun alloué pour lire
                c.setReadTimeout(60000);
                //flux de lecture avec l'encodage des caractères UTF-8
                BufferedReader in = new BufferedReader(
                        new InputStreamReader(c.getInputStream(), "UTF-8"));
                while ((inputline = in.readLine()) != null) {
                    //concaténation+retour à la ligne avec \n
                    codeHTML.append(inputline + "\n");
                }
                //il faut bien fermer le flux de lecture
                in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return codeHTML.toString();
        });
    }
}